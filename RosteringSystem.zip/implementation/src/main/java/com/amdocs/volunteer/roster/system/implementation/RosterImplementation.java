package com.amdocs.volunteer.roster.system.implementation;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.amdocs.volunteer.roster.system.bean.Volunteer;
import com.amdocs.volunteer.roster.system.constants.RosterConstants;
import com.amdocs.volunteer.roster.system.exception.RosterException;
import com.amdocs.volunteer.roster.system.printer.AllocationPrinter;
import com.amdocs.volunteer.roster.system.processor.RosterProcessor;
import com.amdocs.volunteer.roster.system.reader.RosterInputReader;

/**
 * This class contains operations to allocate volunteers in shifts
 * @Operations: process
 * @Developer: Ganguly, Suman
 */

public class RosterImplementation {
	
	private static final Logger logger = Logger.getLogger(RosterImplementation.class.getName());
	
	private RosterProcessor processor;
	private AllocationPrinter printer;
	private RosterInputReader reader;
	
	public void setProcessor(RosterProcessor processor) {
		this.processor = processor;
	}
	public void setPrinter(AllocationPrinter printer) {
		this.printer = printer;
	}
	public void setReader(RosterInputReader reader) {
		this.reader = reader;
	}

	/**
	 * The following operation processes the roster generation request
	 * @Input - filePath
	 * @Response - None
	 * @Exception - None
	 */
	public void process(String filePath) {
		List<Volunteer> volunteers = null;
		try {
			/*
			 * Following statement reads data from xls file and prepares list of volunteer objects
			 */		  
			logger.info("Calling input reader to process the input");
			volunteers = reader.readAvailabilityData(filePath);
			/*
			 * Following statement generates the roster
			 */		        	
			logger.info("Calling roster processor to generate roster");
			processor.generateRoster(volunteers);
		} catch (RosterException re) {
			logger.log(Level.SEVERE, re.getErrorCode() + ":" + re.getMessage());
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "Unknown Exception occurred while implementing the roster solution", ex);
		}
		/*
		 * Following statement prints the allocation
		 */		        	
		logger.info("Calling roster print to proint the roster");
		printer.printAllocation(volunteers);
	}
}
