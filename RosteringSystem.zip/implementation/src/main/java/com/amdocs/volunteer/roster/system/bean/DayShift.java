package com.amdocs.volunteer.roster.system.bean;

import com.amdocs.volunteer.roster.system.constants.RosterConstants;
import com.amdocs.volunteer.roster.system.utility.Day;
import com.amdocs.volunteer.roster.system.utility.Shift;

/**
 * This class composed on Day and Shift enumeration objects to represent a particular shift in a day
 * @Operations: constructor and getter/setters
 * @Developer: Ganguly, Suman
 */
public class DayShift {
	
	private Day day;
	private Shift shift;
	
	public DayShift(Day day, Shift shift) {
		this.day = day;
		this.shift = shift;
	}
	public DayShift(String dayShift) {
		if(dayShift != null && dayShift.contains(RosterConstants.KEY_SEPERATOR_CHARACTER)) {
			this.day = Day.fromString(dayShift.substring(0, dayShift.indexOf(RosterConstants.KEY_SEPERATOR_CHARACTER)));
			this.shift = Shift.fromString(dayShift.substring(dayShift.indexOf(RosterConstants.KEY_SEPERATOR_CHARACTER)+1, dayShift.length()));
		}
	}
	
	public Day getDay() {
		return day;
	}
	public void setDay(Day day) {
		this.day = day;
	}
	public Shift getShift() {
		return shift;
	}
	public void setShift(Shift shift) {
		this.shift = shift;
	}
}
