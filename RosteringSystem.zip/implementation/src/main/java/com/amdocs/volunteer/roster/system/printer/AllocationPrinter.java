package com.amdocs.volunteer.roster.system.printer;

import java.util.List;

import com.amdocs.volunteer.roster.system.bean.DayShift;
import com.amdocs.volunteer.roster.system.bean.Volunteer;
import com.amdocs.volunteer.roster.system.constants.RosterConstants;
import com.amdocs.volunteer.roster.system.utility.Day;
import com.amdocs.volunteer.roster.system.utility.RosterHelper;

/**
 * This class contains operations to print allocation
 * @Operations: printAllocation
 * @Developer: Ganguly, Suman
 */

public class AllocationPrinter {
	
	/**
	 * The following operation prints the allocation in console
	 * It prints the values in a table having rows and column
	 * Maximum size of text in a column has been consider as 12 characters.
	 * If Input Name greater than 15 characters, then constant MAX_PRINT_STRING_SIZE need to be modified in RosterConstants
	 * @Input - List<Volunteer>
	 * @Response - none
	 * @Exception - None
	 */
	public void printAllocation(List<Volunteer> volunteers) {
		/*
		 * Following loop prints the table header top border
		 * There are 6 columns (5 Days and 1 Name) and additional 5 extra separator between columns
		 */		        	
		for(int iCounter=0; iCounter < (RosterConstants.MAX_PRINT_STRING_SIZE * 6)+5; iCounter++) {
			System.out.print(RosterConstants.PRINT_ROW_SEPERATOR_CHARACTER);
		}
		/*
		 * Following section prints the table header
		 */		        	
		System.out.println(RosterConstants.PRINT_BLANK_CHARACTER);
		System.out.print(RosterHelper.formatPrintData(RosterConstants.PRINT_TABLE_HEADER));
		for(Day day: Day.values()) {
			System.out.print(RosterConstants.PRINT_COLUMN_SEPERATOR_CHARACTER + RosterHelper.formatPrintData(day.toString()));
		}
		System.out.println(RosterConstants.PRINT_BLANK_CHARACTER);
		/*
		 * Following loop prints the table header lower border 
		 * There are 6 columns (5 Days and 1 Name) and additional 5 extra separator between columns
		 */		        	
		for(int iCounter=0; iCounter < (RosterConstants.MAX_PRINT_STRING_SIZE * 6)+5; iCounter++) {
			System.out.print(RosterConstants.PRINT_ROW_SEPERATOR_CHARACTER);
		}
		/*
		 * Following loop prints the allocation of the volunteers 
		 * There are 6 columns (5 Days and 1 Name) and additional 5 extra separator between columns
		 */		        	
		for(Volunteer volunteerPrint: volunteers) {
			System.out.print("\n" + RosterHelper.formatPrintData(volunteerPrint.getName()));
			for(Day day: Day.values()) {
				boolean alocationExists = false;
				for(DayShift dayShift: volunteerPrint.getAllocation()) {
					if(day == dayShift.getDay()) {
						System.out.print(RosterConstants.PRINT_COLUMN_SEPERATOR_CHARACTER + RosterHelper.formatPrintData(dayShift.getShift().toString()));
						alocationExists = true;
					}
				}
				/*
				 * If no allocation exists, print blank characters
				 */		        	
				if(!alocationExists) {
					System.out.print(RosterConstants.PRINT_COLUMN_SEPERATOR_CHARACTER + RosterHelper.formatPrintData(RosterConstants.PRINT_BLANK_CHARACTER));
				}
			}
		}
		System.out.println(RosterConstants.PRINT_BLANK_CHARACTER);
	}
}
