package com.amdocs.volunteer.roster.system.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.amdocs.volunteer.roster.system.bean.DayShift;
import com.amdocs.volunteer.roster.system.bean.Volunteer;
import com.amdocs.volunteer.roster.system.constants.RosterConstants;
import com.amdocs.volunteer.roster.system.exception.RosterException;
import com.amdocs.volunteer.roster.system.utility.Day;
import com.amdocs.volunteer.roster.system.utility.Shift;

/**
 * This class contains operations to allocate volunteers in shifts
 * @Operations: generateRoster
 * @Developer: Ganguly, Suman
 */
public class RosterProcessor {
	
	private static final Logger logger = Logger.getLogger(RosterProcessor.class.getName());
	
	/**
	 * The following operation generates the roster
	 * @Input - List<Volunteer>
	 * @Response - List<Volunteer>
	 * @Exception - RosterException
	 */
	public List<Volunteer> generateRoster(List<Volunteer> volunteers) throws RosterException {
		
		List<String> lastIndex = lastIndex = new ArrayList<String>();
		if(volunteers != null) {
			/*
			 * number of volunteers must be less than or equal to maximum possible shifts in a week
			 * and also greater than or equal to maximum possible shifts in a week divided by maximum allowed shifts for a volunteers per week
			 */		        	
			if(volunteers.size() <= RosterConstants.MAX_VOLUNTEERS_COUNT_PER_WEEK && volunteers.size() >= (int)Math.ceil((double)RosterConstants.MAX_VOLUNTEERS_COUNT_PER_WEEK / RosterConstants.MAX_SHIFT_PER_WEEEK)) {
				/*
				 * get the maximum allocation allowed for a volunteers to evenly distribute the shifts
				 */		        	
				logger.info("Calculate the maximum allocation allowed for a volunteers");
				int maxAllocationCountPerHead = (int)Math.ceil((double)RosterConstants.MAX_VOLUNTEERS_COUNT_PER_WEEK / volunteers.size());
				/*
				 * identify the volunteer having minimum availability so that the application can be started on least availability
				 */		        	
				logger.info("Identify the volunteer having minimum availability");
				int leastAvailableIndex = minAvailabilityVolunteer(volunteers, lastIndex);
				Map<String, Integer> allocationCountPerShift = new HashMap<String, Integer>();
				
				logger.info("Starting the allocation process based on minimum availability of volunteer");
				while(leastAvailableIndex != -1) {
					int currentAllocationCount = 0;
					for(Day day: Day.values()) {
						for(Shift shift: Shift.values()) {							
							/*
							 * Based on least availability, allocation is done on following condition
							 * 1) Volunteer is available on a day-shift
							 * 2) No allocation done yet on that day
							 * 3) Maximum allocation per week threshold has not been reached
							 * 4) Maximum evenly allocation threshold is not reached
							 * 5) Maximum person count on the same day shift allocation is below allowed limit
							 */		        	
							if(!shift.equals(Shift.EITHER)
									&& volunteers.get(leastAvailableIndex).availableOnDayShift(day, shift)
									&& !volunteers.get(leastAvailableIndex).allocatedOnDayShift(day)
									&& !volunteers.get(leastAvailableIndex).maxWeekShiftReached()
									&& currentAllocationCount < maxAllocationCountPerHead
									&& (allocationCountPerShift.get(day+RosterConstants.KEY_SEPERATOR_CHARACTER+shift) == null
											|| (allocationCountPerShift.get(day+RosterConstants.KEY_SEPERATOR_CHARACTER+shift) != null && allocationCountPerShift.get(day+RosterConstants.KEY_SEPERATOR_CHARACTER+shift).intValue() < RosterConstants.MIN_VOLUNTEER_PER_SHIFT))) {
								volunteers.get(leastAvailableIndex).setAllocation(new DayShift(day, shift));
								currentAllocationCount = currentAllocationCount + 1;
								
								if(allocationCountPerShift.get(day+RosterConstants.KEY_SEPERATOR_CHARACTER+shift) == null) {
									allocationCountPerShift.put(day+RosterConstants.KEY_SEPERATOR_CHARACTER+shift, new Integer(1));
								} else {
									allocationCountPerShift.put(day+RosterConstants.KEY_SEPERATOR_CHARACTER+shift, new Integer(allocationCountPerShift.get(day+RosterConstants.KEY_SEPERATOR_CHARACTER+shift).intValue()+ 1));
								}
							}
						}
					}
					leastAvailableIndex = minAvailabilityVolunteer(volunteers, lastIndex);
				}
				
				/*
				 * Even after the allocation is done using least available volunteer, there is still a chance that
				 * adequate volunteers will not be allocated on all shifts
				 * Following section will identify which all shifts has not been filled up up with adequate volunteers
				 * 1) If any volunteers maximum allocation not reached and available on a shift where adequate volunteers not allocated,
				 *    system will allocate the volunteer on that shift
				 * 2) If volunteer maximum allocated reached, but is available on a shift where adequate volunteers not allocated,
				 *    system will identify another volunteer with whom allocation can be swapped
				 */		   
				logger.info("Allocation done, checking shift wise minimum volunteers allocation");
				for(String dayShiftKey: allocationCountPerShift.keySet()) {
					if(allocationCountPerShift.get(dayShiftKey).intValue() < RosterConstants.MIN_VOLUNTEER_PER_SHIFT) {
						for(Volunteer volunteer: volunteers) {
							if(volunteer.availableOnDayShift(new DayShift(dayShiftKey).getDay(), new DayShift(dayShiftKey).getShift())) {
								if(!volunteer.allocatedOnDayShift(new DayShift(dayShiftKey).getDay())) {
									if(!volunteer.maxWeekShiftReached()) {
										volunteer.setAllocation(new DayShift(dayShiftKey));
									} else {										
										if(isShiftPossible(volunteers, volunteer, dayShiftKey, allocationCountPerShift)) {
											volunteer.setAllocation(new DayShift(dayShiftKey));
											break;
										}
									}
								}
							}
						}
					}
				}
				
				/*
				 * System will raise exception if for all shifts, adequate volunteers are not allocated
				 */		  
				logger.info("Checking shift wise minimum volunteers allocation, so that exception can be raised if required");
				for(String dayShiftKey: allocationCountPerShift.keySet()) {
					if(allocationCountPerShift.get(dayShiftKey).intValue() < RosterConstants.MIN_VOLUNTEER_PER_SHIFT) {
						logger.log(Level.SEVERE, "Minimum volunteers can be allocated for shift: "+ dayShiftKey);
						throw new RosterException(RosterConstants.ERROR_CODE_ALLOCATION_THRESHOLD_EXCEPTION, RosterConstants.ERROR_MESSAGE_ALLOCATION_THRESHOLD_EXCEPTION);
					}
				}
				logger.info("Checking whether all volunteers got at least one allocation and less than maximum allowed");
				for(Volunteer volunteer: volunteers) {
					/*
					 * System will raise exception if
					 * 1) Allocation is done more than maximum allocated allowed per week threshold
					 */		   
					if(volunteer.getAllocation().size() > RosterConstants.MAX_SHIFT_PER_WEEEK) {
						logger.log(Level.SEVERE, "Allocation is done more than maximum allocated allowed per week threshold for volunteer: "+volunteer.getName());
						throw new RosterException(RosterConstants.ERROR_CODE_OVER_ALLOCATION_EXCEPTION, RosterConstants.ERROR_MESSAGE_OVER_ALLOCATION_EXCEPTION.replace(RosterConstants.VOLUNTEER_REPLACE_TEXT, volunteer.getName()));
					}
					/*
					 * System will raise exception if
					 * 2) Allocation failed to meet minimum allocation required for a volunteer in a week
					 */		   
					if(volunteer.getAllocation().size() == 0) {
						logger.log(Level.SEVERE, "Allocation failed to meet minimum allocation required for a volunteer in a week for volunteer: "+volunteer.getName());
						throw new RosterException(RosterConstants.ERROR_CODE_MINIMUM_ALLOCATION_EXCEPTION, RosterConstants.ERROR_MESSAGE_MINIMUM_ALLOCATION_EXCEPTION.replace(RosterConstants.VOLUNTEER_REPLACE_TEXT, volunteer.getName()));
					}
				}
				
			} else {
				/*
				 * System will raise exception if
				 * 1) number of volunteers greater than maximum possible shifts in a week
				 * 2) and also less than maximum possible shifts in a week divided by maximum allowed shifts for a volunteers per week
				 */		   
				if(volunteers.size() > RosterConstants.MAX_VOLUNTEERS_COUNT_PER_WEEK) {
					logger.log(Level.SEVERE, "Number of volunteers greater than maximum possible shifts in a week");
					throw new RosterException(RosterConstants.ERROR_CODE_MAX_SHIFT_EXCEPTION, RosterConstants.ERROR_MESSAGE_MAX_SHIFT_EXCEPTION);
				} else {
					logger.log(Level.SEVERE, "Number of volunteers less than maximum possible shifts in a week divided by maximum allowed shifts for a volunteers per week");
					throw new RosterException(RosterConstants.ERROR_CODE_MIN_SHIFT_EXCEPTION, RosterConstants.ERROR_MESSAGE_MIN_SHIFT_EXCEPTION);
				}
			}
		}
		
		return volunteers;
	}
	
	/**
	 * The following private operation used by the roster generator to find the next volunteer having least availability
	 * @Input - List<Volunteer>, List<String> lastIndex
	 * @Response - volunteer index
	 * @Exception - None
	 */
	private int minAvailabilityVolunteer(List<Volunteer> volunteers, List<String> lastIndex) {
		Volunteer minAvailableVolunteer = null;
		int leastAvailableIndex = -1;
		int volunteerIndex = 0;
		/*
		 * Loop through the volunteers list and identify next least available volunteer
		 */		   
		for(Volunteer volunteer: volunteers) {
			if ((minAvailableVolunteer == null || (minAvailableVolunteer != null && volunteer.getAvailability().size() < minAvailableVolunteer.getAvailability().size()))
					&& lastIndex.indexOf(volunteerIndex + RosterConstants.PRINT_BLANK_CHARACTER) == -1) {
				leastAvailableIndex = volunteerIndex;
				minAvailableVolunteer = volunteer;
			}
			volunteerIndex = volunteerIndex + 1;
		}
		lastIndex.add(leastAvailableIndex+RosterConstants.PRINT_BLANK_CHARACTER);
		return leastAvailableIndex;
	}	
	
	/**
	 * The following private operation used by the roster generator check if a shift is possible to complete the allocation 
	 * with specified guidelines
	 * @Input - List<Volunteer>, volunteerIdentified, dayShiftKey, allocationCountPerShift
	 * @Response - boolean
	 * @Exception - None
	 */
	private boolean isShiftPossible(List<Volunteer> volunteers, Volunteer volunteerIdentified, String dayShiftKey, Map<String, Integer> allocationCountPerShift) {
		boolean shiftPossible = false;
		for(DayShift dayShift: volunteerIdentified.getAllocation()) {
			/*
			 * The following section identifies and swaps allocation between volunteers
			 * This section swaps allocation on the day shift where a volunteer
			 * 1) Did not reached maximum allowed allocation per week
			 * 2) Available on a shift which can be swapped with identified volunteer, so that identified volunteer can
			 *    be allocated to the shift which does not meet minimum volunteer per shift threshold
			 */		   
			if(!(dayShift.getDay()+RosterConstants.KEY_SEPERATOR_CHARACTER+dayShift.getShift()).equals(dayShiftKey)) {	
				for(Volunteer volunteer: volunteers) {
					if(volunteer.availableOnDayShift(dayShift.getDay(), dayShift.getShift())
							&& !volunteer.allocatedOnDayShift(dayShift.getDay())
							&& !volunteer.getName().equals(volunteerIdentified.getName())
							&& !volunteer.maxWeekShiftReached()) {
						volunteer.setAllocation(dayShift);
						shiftPossible = true;
						break;
					}
				}
				if(shiftPossible) {
					for(Volunteer volunteer: volunteers) {
						if(volunteer.getName().equals(volunteerIdentified.getName())) {
							volunteer.removeAllocation(dayShift);
							break;
						}
					}
				}
			}
			if(shiftPossible) {
				allocationCountPerShift.put(dayShiftKey, new Integer(allocationCountPerShift.get(dayShiftKey).intValue()+1));
				break;
			}
		}
		return shiftPossible;
	}
}
