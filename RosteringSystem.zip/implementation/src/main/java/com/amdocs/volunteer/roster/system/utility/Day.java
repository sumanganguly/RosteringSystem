package com.amdocs.volunteer.roster.system.utility;

/**
 * This enum class contains different possible Day options
 * @Operations: fromString
 * @Developer: Ganguly, Suman
 */
public enum Day {
	
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY;
	
	/**
	 * The following operation generates Day enum object from input string
	 * @Input - input
	 * @Response - Day
	 * @Exception - None
	 */
	public static Day fromString(String input) {
		if (input != null) {
			for (Day day : Day.values()) {
				if (input.equalsIgnoreCase(day.toString())) {
					return day;
				}
			}
		}
		return null;
	}
}
