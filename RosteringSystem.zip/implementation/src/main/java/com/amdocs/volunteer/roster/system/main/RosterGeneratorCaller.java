package com.amdocs.volunteer.roster.system.main;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.amdocs.volunteer.roster.system.implementation.RosterImplementation;

/**
 * This class contains operations to load spring context and call the implementation
 * @Operations: main
 * @Developer: Ganguly, Suman
 */

public class RosterGeneratorCaller {
	
	private static final Logger logger = Logger.getLogger(RosterGeneratorCaller.class.getName());
	
	/**
	 * The following operation loads spring context and calls implementation to generate roster
	 * @Input - input xlsx file path as command line argument
	 * @Response - None
	 * @Exception - None
	 */
	public static void main(String[] args) {
		
		if(args != null && args.length > 0 && !args[0].equals("")) {
			/*
			 * Following statements loads Spring application context
			 */		        	
			logger.info("Loading Spring application context");
			ApplicationContext ctx = new ClassPathXmlApplicationContext("application-context.xml");
			RosterImplementation implementation = (RosterImplementation)ctx.getBean("roosterImplementation");
			/*
			 * Following statements calls the implementation calls to generate roster
			 */		        	
			logger.info("Calling roster implementation to handle the request");
			implementation.process(args[0]);		
			logger.info("Leaving the caller after handling the request");
		} else {
			logger.log(Level.SEVERE, "Invalid input specified, you must provide input excel file location");
		}
	}
}
