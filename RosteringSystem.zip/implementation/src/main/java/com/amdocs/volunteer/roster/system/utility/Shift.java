package com.amdocs.volunteer.roster.system.utility;

/**
 * This enum class contains different possible Shift options
 * @Operations: fromString
 * @Developer: Ganguly, Suman
 */
public enum Shift {
	
	MORNING, AFTERNOON, EITHER;
	
	/**
	 * The following operation generates Shift enum object from input string
	 * @Input - input
	 * @Response - Shift
	 * @Exception - None
	 */
	public static Shift fromString(String input) {
		if (input != null) {
			for (Shift shift : Shift.values()) {
				if (input.equalsIgnoreCase(shift.toString())) {
					return shift;
				}
			}
		}
		return null;
	}
}
