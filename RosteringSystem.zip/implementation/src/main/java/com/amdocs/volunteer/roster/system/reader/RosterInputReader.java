package com.amdocs.volunteer.roster.system.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.amdocs.volunteer.roster.system.bean.DayShift;
import com.amdocs.volunteer.roster.system.bean.Volunteer;
import com.amdocs.volunteer.roster.system.constants.RosterConstants;
import com.amdocs.volunteer.roster.system.exception.RosterException;
import com.amdocs.volunteer.roster.system.implementation.RosterImplementation;
import com.amdocs.volunteer.roster.system.utility.Day;
import com.amdocs.volunteer.roster.system.utility.Shift;

/**
 * This class contains operations to process input xls file and generate list of volunteers with availability matrix
 * @Operations: readAvailabilityData
 * @Developer: Ganguly, Suman
 */
public class RosterInputReader {
	
	private static final Logger logger = Logger.getLogger(RosterImplementation.class.getName());
	
	/**
	 * The following operation reads the input excel file and generates list of Volunteers with availability matrix 
	 * @Input - filePath
	 * @Response - List<Volunteer>
	 * @Exception - RosterException
	 */
	public List<Volunteer> readAvailabilityData(String filePath) throws RosterException {
		
		List<Volunteer> volunteers = new ArrayList<Volunteer>();
		Volunteer volunteer = null;
		try {
			logger.info("Creating the File Input Stream to access the workbook");
			FileInputStream fileInputStream = new FileInputStream(new File(filePath));
			Workbook workbook = new XSSFWorkbook(fileInputStream);
			Sheet firstSheet = workbook.getSheetAt(0);
	        Iterator<Row> iterator = firstSheet.iterator();
			
			int irowCounter = 0;
			Shift shift = null;
			
			logger.info("Processing rows in the workbook");
	        while (iterator.hasNext()) {
	            Row nextRow = iterator.next();
				/*
				 * First row in the worksheet must be the header row having week days
				 * Week name must match the allowed names and must be in a proper order
				 */		        	
				if(irowCounter == 0) {
					if(!(nextRow.getCell(1).getStringCellValue().trim().equalsIgnoreCase(Day.MONDAY.toString())
							&& nextRow.getCell(2).getStringCellValue().trim().equalsIgnoreCase(Day.TUESDAY.toString())
							&& nextRow.getCell(3).getStringCellValue().trim().equalsIgnoreCase(Day.WEDNESDAY.toString())
							&& nextRow.getCell(4).getStringCellValue().trim().equalsIgnoreCase(Day.THURSDAY.toString())
							&& nextRow.getCell(5).getStringCellValue().trim().equalsIgnoreCase(Day.FRIDAY.toString())
							)) {
						logger.log(Level.SEVERE, "Input excel file does not contain proper header information, it must be in order - MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY");
						throw new RosterException(RosterConstants.ERROR_CODE_INVALID_HEADER_EXCEPTION, RosterConstants.ERROR_MESSAGE_INVALID_HEADER_EXCEPTION);
					} 
				} else {
					/*
					 * Following rows must be having the volunteer names and availability
					 * availability text must be within allowed options
					 */		        	
					volunteer = new Volunteer();
					if(nextRow.getCell(0) != null && !nextRow.getCell(0).getStringCellValue().trim().equals("")) {
						volunteer.setName(nextRow.getCell(0).getStringCellValue().trim());
					}
					if(nextRow.getCell(1) != null && !nextRow.getCell(1).getStringCellValue().trim().equals("")) {
						shift = Shift.fromString(nextRow.getCell(1).getStringCellValue().trim());
						if(shift == null) {
							logger.log(Level.SEVERE, "Invalid shift data provided in cell ("+(irowCounter+1)+", 2)");
							throw new RosterException(RosterConstants.ERROR_CODE_INVALID_SHIFT_FOUND_EXCEPTION, RosterConstants.ERROR_MESSAGE_INVALID_SHIFT_FOUND_EXCEPTION);
						}
						volunteer.setAvailability(new DayShift(Day.MONDAY, shift));
					}
					if(nextRow.getCell(2) != null && !nextRow.getCell(2).getStringCellValue().trim().equals("")) {
						shift = Shift.fromString(nextRow.getCell(2).getStringCellValue().trim());
						if(shift == null) {
							logger.log(Level.SEVERE, "Invalid shift data provided in cell ("+(irowCounter+1)+", 3)");
							throw new RosterException(RosterConstants.ERROR_CODE_INVALID_SHIFT_FOUND_EXCEPTION, RosterConstants.ERROR_MESSAGE_INVALID_SHIFT_FOUND_EXCEPTION);
						}
						volunteer.setAvailability(new DayShift(Day.TUESDAY, shift));
					}
					if(nextRow.getCell(3) != null && !nextRow.getCell(3).getStringCellValue().trim().equals("")) {
						shift = Shift.fromString(nextRow.getCell(3).getStringCellValue().trim());
						if(shift == null) {
							logger.log(Level.SEVERE, "Invalid shift data provided in cell ("+(irowCounter+1)+", 4)");
							throw new RosterException(RosterConstants.ERROR_CODE_INVALID_SHIFT_FOUND_EXCEPTION, RosterConstants.ERROR_MESSAGE_INVALID_SHIFT_FOUND_EXCEPTION);
						}
						volunteer.setAvailability(new DayShift(Day.WEDNESDAY, shift));
					}
					if(nextRow.getCell(4) != null && !nextRow.getCell(4).getStringCellValue().trim().equals("")) {
						shift = Shift.fromString(nextRow.getCell(4).getStringCellValue().trim());
						if(shift == null) {
							logger.log(Level.SEVERE, "Invalid shift data provided in cell ("+(irowCounter+1)+", 5)");
							throw new RosterException(RosterConstants.ERROR_CODE_INVALID_SHIFT_FOUND_EXCEPTION, RosterConstants.ERROR_MESSAGE_INVALID_SHIFT_FOUND_EXCEPTION);
						}
						volunteer.setAvailability(new DayShift(Day.THURSDAY, shift));
					}
					if(nextRow.getCell(5) != null && !nextRow.getCell(5).getStringCellValue().trim().equals("")) {
						shift = Shift.fromString(nextRow.getCell(5).getStringCellValue().trim());
						if(shift == null) {
							logger.log(Level.SEVERE, "Invalid shift data provided in cell ("+(irowCounter+1)+", 6)");
							throw new RosterException(RosterConstants.ERROR_CODE_INVALID_SHIFT_FOUND_EXCEPTION, RosterConstants.ERROR_MESSAGE_INVALID_SHIFT_FOUND_EXCEPTION);
						}
						volunteer.setAvailability(new DayShift(Day.FRIDAY, shift));
					}
					volunteers.add(volunteer);
					
				}
				irowCounter = irowCounter + 1;	             
	        }
	        fileInputStream.close();	        
	        
		} catch (FileNotFoundException fne) {
			logger.log(Level.SEVERE, "File Not Found Exception occurred while reading the file from input stream", fne);
			throw new RosterException(RosterConstants.ERROR_CODE_FILE_NOT_FOUND_EXCEPTION, RosterConstants.ERROR_MESSAGE_FILE_NOT_FOUND_EXCEPTION);
		} catch (IOException ioe) {
			logger.log(Level.SEVERE, "IO Exception occurred while reading the file from input stream", ioe);
			throw new RosterException(RosterConstants.ERROR_CODE_IO_EXCEPTION, RosterConstants.ERROR_MESSAGE_IO_EXCEPTION);
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "Unknown Exception occurred while reading the file from input stream", ex);
			throw new RosterException(RosterConstants.ERROR_CODE_UNKNOWN_EXCEPTION, RosterConstants.ERROR_MESSAGE_UNKNOWN_EXCEPTION);
		}	
		return volunteers;
	}
}
