package com.amdocs.volunteer.roster.system.constants;

/**
 * This class contains constant variables to be used the application
 * @Operations: None
 * @Developer: Ganguly, Suman
 */

public interface RosterConstants {
	
	public static int MIN_VOLUNTEER_PER_SHIFT = 2;
	public static int MAX_SHIFT_PER_WEEEK = 3;
	public static int MAX_SHIFT_PER_DAY = 1;
	public static int MAX_DAYS_PER_WEEK = 5;
	public static int MAX_VOLUNTEERS_COUNT_PER_WEEK = 20;
	
	public static String MORNING_SHIFT = "Morning";
	public static String AFTERNOON_SHIFT = "Afternoon";
	public static String EITHER_SHIFT = "Either";
	public static String KEY_SEPERATOR_CHARACTER = "-";
	
	public static int MAX_PRINT_STRING_SIZE = 15;
	public static String PRINT_PADDING_CHARACTER = " ";
	public static String PRINT_BLANK_CHARACTER = "";
	public static String PRINT_COLUMN_SEPERATOR_CHARACTER = "|";
	public static String PRINT_ROW_SEPERATOR_CHARACTER = "-";
	public static String PRINT_TABLE_HEADER = "NAME/DAY";
	public static String VOLUNTEER_REPLACE_TEXT = "$volunteer";
	
	/**
	 * Error codes and messages
	 */
	public static String ERROR_CODE_IO_EXCEPTION = "IE00";
	public static String ERROR_MESSAGE_IO_EXCEPTION = "IO Exception occured while processing the request";

	public static String ERROR_CODE_FILE_NOT_FOUND_EXCEPTION = "FN00";
	public static String ERROR_MESSAGE_FILE_NOT_FOUND_EXCEPTION = "File Not Found Exception occured while processing the request";

	public static String ERROR_CODE_INVALID_SHIFT_FOUND_EXCEPTION = "IS00";
	public static String ERROR_MESSAGE_INVALID_SHIFT_FOUND_EXCEPTION = "Invalid shift information provided in the input file";
	
	public static String ERROR_CODE_UNKNOWN_EXCEPTION = "UE00";
	public static String ERROR_MESSAGE_UNKNOWN_EXCEPTION = "Unknown error occured while processing the request";
	
	public static String ERROR_CODE_INVALID_HEADER_EXCEPTION = "IH00";
	public static String ERROR_MESSAGE_INVALID_HEADER_EXCEPTION = "Invalid header found in the in put file";
	
	public static String ERROR_CODE_MAX_SHIFT_EXCEPTION = "MS00";
	public static String ERROR_MESSAGE_MAX_SHIFT_EXCEPTION = "Input file contains more resources than maximum allowed allocation per week";

	public static String ERROR_CODE_MIN_SHIFT_EXCEPTION = "MS01";
	public static String ERROR_MESSAGE_MIN_SHIFT_EXCEPTION = "Input file contains less resources than minimum allowed allocation per week";

	public static String ERROR_CODE_ALLOCATION_THRESHOLD_EXCEPTION = "AT00";
	public static String ERROR_MESSAGE_ALLOCATION_THRESHOLD_EXCEPTION = "Could not allocate at-least two resources for each shift";
	
	public static String ERROR_CODE_OVER_ALLOCATION_EXCEPTION = "OA00";
	public static String ERROR_MESSAGE_OVER_ALLOCATION_EXCEPTION = "Volunteer $volunteer allocated more than allowed allocation per week";

	public static String ERROR_CODE_MINIMUM_ALLOCATION_EXCEPTION = "MA00";
	public static String ERROR_MESSAGE_MINIMUM_ALLOCATION_EXCEPTION = "Volunteer $volunteer is not allocated minimum allocation per week";
	
}
