package com.amdocs.volunteer.roster.system.utility;

import com.amdocs.volunteer.roster.system.constants.RosterConstants;
/**
 * This class contains utility methods for rooster allocation
 * @Operations: formatPrintData
 * @Developer: Ganguly, Suman
 */
public class RosterHelper {

	/**
	 * The following operation generates fixed length right padded string of length RosterConstants.MAX_PRINT_STRING_SIZE
	 * @Input - textToPrint
	 * @Response - right padded string
	 * @Exception - None
	 */
	public static String formatPrintData(String textToPrint) {
		if(textToPrint != null) {
			while(textToPrint.length() < RosterConstants.MAX_PRINT_STRING_SIZE) {
				textToPrint =  textToPrint + RosterConstants.PRINT_PADDING_CHARACTER;
			}
			return textToPrint;
		}		
		return null;
	}
}
