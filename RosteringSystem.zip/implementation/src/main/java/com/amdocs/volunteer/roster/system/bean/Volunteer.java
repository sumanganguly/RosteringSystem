package com.amdocs.volunteer.roster.system.bean;

import java.util.ArrayList;
import java.util.List;

import com.amdocs.volunteer.roster.system.constants.RosterConstants;
import com.amdocs.volunteer.roster.system.utility.Day;
import com.amdocs.volunteer.roster.system.utility.RosterHelper;
import com.amdocs.volunteer.roster.system.utility.Shift;

/**
 * This bean class contains attributes, availability and allocation status for each volunteer
 * @Operations: availableOnDayShift, removeAllocation, allocatedOnDayShift, maxWeekShiftReached, printAllocation
 * @Developer: Ganguly, Suman
 */
public class Volunteer {
	
	private String name;
	private List<DayShift> availability;
	private List<DayShift> allocation;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<DayShift> getAvailability() {
		if(this.availability == null) {
			this.availability = new ArrayList<DayShift>();
		}
		return availability;
	}
	public void setAvailability(DayShift dayShift) {
		if(this.availability == null) {
			this.availability = new ArrayList<DayShift>();
		}
		if(dayShift != null) {
			this.availability.add(dayShift);
		}
	}
	public List<DayShift> getAllocation() {
		if(this.allocation == null) {
			this.allocation = new ArrayList<DayShift>();
		}
		return allocation;
	}
	
	public void setAllocation(DayShift dayShift) {
		if(this.allocation == null) {
			this.allocation = new ArrayList<DayShift>();
		}
		if(dayShift != null) {
			this.allocation.add(dayShift);
		}
	}
	
	/**
	 * The following operation checks whether a volunteer has allocation on a particular day and shift
	 * @Input - Day, Shift
	 * @Response - boolean
	 * @Exception - None
	 */
	public boolean availableOnDayShift(Day day, Shift shift) {
		if(day != null && shift != null && this.availability != null) {
			for(DayShift dayShift: this.availability) {
				if(dayShift.getDay().toString().equals(day.toString())
						&& (dayShift.getShift().toString().equals(shift.toString())
								|| dayShift.getShift().toString().equals(Shift.EITHER.toString()))) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * The following operation removes allocation on a particular day and shift
	 * @Input - DayShift
	 * @Response - None
	 * @Exception - None
	 */
	public void removeAllocation(DayShift dayshift) {
		if(dayshift != null && this.allocation != null) {
			for(int iCounter=0; iCounter<this.allocation.size(); iCounter++) {
				if(this.allocation.get(iCounter).getDay() == dayshift.getDay()
						&& this.allocation.get(iCounter).getShift() == dayshift.getShift()) {
					this.allocation.remove(iCounter);
					break;
				}
			}
		}
	}
	
	
	/**
	 * The following operation checks whether a volunteer has allocation on a particular day
	 * @Input - Day
	 * @Response - boolean
	 * @Exception - None
	 */
	public boolean allocatedOnDayShift(Day day) {
		if(day != null && this.allocation != null) {
			for(DayShift dayShift: this.allocation) {
				if(dayShift.getDay().toString().equals(day.toString())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * The following operation checks whether a volunteer reached maximum allocation on not
	 * @Input - None
	 * @Response - boolean
	 * @Exception - None
	 */
	public boolean maxWeekShiftReached() {
		if(this.allocation != null && this.allocation.size() >= RosterConstants.MAX_SHIFT_PER_WEEEK) {
			return true;
		}
		return false;
	}
	
	/**
	 * The following operation prints the allocation for a volunteer
	 * @Input - None
	 * @Response - None
	 * @Exception - None
	 */
	public void printAllocation() {
		if(this.allocation != null) {
			System.out.print("\n" + RosterHelper.formatPrintData(this.name));
			for(Day day: Day.values()) {
				boolean alocationExists = false;
				for(DayShift dayShift: this.allocation) {
					if(day == dayShift.getDay()) {
						System.out.print(RosterConstants.PRINT_COLUMN_SEPERATOR_CHARACTER + RosterHelper.formatPrintData(dayShift.getShift().toString()));
						alocationExists = true;
					}
				}
				if(!alocationExists) {
					System.out.print(RosterConstants.PRINT_COLUMN_SEPERATOR_CHARACTER + RosterHelper.formatPrintData(""));
				}
			}
		}
	}
}
