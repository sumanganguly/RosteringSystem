package com.amdocs.volunteer.roster.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.amdocs.volunteer.roster.system.bean.DayShift;
import com.amdocs.volunteer.roster.system.bean.Volunteer;
import com.amdocs.volunteer.roster.system.exception.RosterException;
import com.amdocs.volunteer.roster.system.printer.AllocationPrinter;
import com.amdocs.volunteer.roster.system.processor.RosterProcessor;
import com.amdocs.volunteer.roster.system.utility.Day;
import com.amdocs.volunteer.roster.system.utility.Shift;

public class RosterSystemTest {
	
	private RosterProcessor processor;
	private AllocationPrinter printer;
	List<Volunteer> volunteers;
	
	@Before
	public void loadContext() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("application-context-test.xml");
		processor = (RosterProcessor)ctx.getBean("roosterProcessor");
		printer = (AllocationPrinter)ctx.getBean("allocationPrinter");

		volunteers = new ArrayList<Volunteer>();
		Volunteer volunteer = new Volunteer();
		volunteer.setName("Andrew");
		volunteer.setAvailability(new DayShift(Day.MONDAY, Shift.AFTERNOON));
		volunteer.setAvailability(new DayShift(Day.TUESDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.WEDNESDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.THURSDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.FRIDAY, Shift.EITHER));
		volunteers.add(volunteer);
		
		volunteer = new Volunteer();
		volunteer.setName("Raj");
		volunteer.setAvailability(new DayShift(Day.MONDAY, Shift.AFTERNOON));
		volunteer.setAvailability(new DayShift(Day.TUESDAY, Shift.AFTERNOON));
		volunteer.setAvailability(new DayShift(Day.WEDNESDAY, Shift.AFTERNOON));
		volunteer.setAvailability(new DayShift(Day.THURSDAY, Shift.AFTERNOON));
		volunteers.add(volunteer);
		
		volunteer = new Volunteer();
		volunteer.setName("Eva");
		volunteer.setAvailability(new DayShift(Day.MONDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.TUESDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.THURSDAY, Shift.MORNING));
		volunteer.setAvailability(new DayShift(Day.FRIDAY, Shift.AFTERNOON));
		volunteers.add(volunteer);
		
		volunteer = new Volunteer();
		volunteer.setName("Mike");
		volunteer.setAvailability(new DayShift(Day.MONDAY, Shift.MORNING));
		volunteer.setAvailability(new DayShift(Day.TUESDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.WEDNESDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.THURSDAY, Shift.EITHER));
		volunteer.setAvailability(new DayShift(Day.FRIDAY, Shift.EITHER));
		volunteers.add(volunteer);

		volunteer = new Volunteer();
		volunteer.setName("John");
		volunteer.setAvailability(new DayShift(Day.WEDNESDAY, Shift.MORNING));
		volunteer.setAvailability(new DayShift(Day.THURSDAY, Shift.MORNING));
		volunteer.setAvailability(new DayShift(Day.FRIDAY, Shift.MORNING));
		volunteers.add(volunteer);

		volunteer = new Volunteer();
		volunteer.setName("Ravi");
		volunteer.setAvailability(new DayShift(Day.WEDNESDAY, Shift.MORNING));
		volunteer.setAvailability(new DayShift(Day.THURSDAY, Shift.MORNING));
		volunteer.setAvailability(new DayShift(Day.FRIDAY, Shift.EITHER));
		volunteers.add(volunteer);
	
		volunteer = new Volunteer();
		volunteer.setName("Kelly");
		volunteer.setAvailability(new DayShift(Day.THURSDAY, Shift.MORNING));
		volunteer.setAvailability(new DayShift(Day.FRIDAY, Shift.MORNING));
		volunteers.add(volunteer);
	
		volunteer = new Volunteer();
		volunteer.setName("Jane");
		volunteer.setAvailability(new DayShift(Day.MONDAY, Shift.AFTERNOON));
		volunteer.setAvailability(new DayShift(Day.WEDNESDAY, Shift.AFTERNOON));
		volunteers.add(volunteer);
	}
	
	@Test
	public void testValidScenario() throws RosterException {
		processor.generateRoster(volunteers);
		printer.printAllocation(volunteers);
	}
	
	@Test
	public void testLessVolunteer() throws RosterException {
		volunteers.remove(6);
		volunteers.remove(6);
		try {
			processor.generateRoster(volunteers);
		} catch(RosterException rx) {
		}
		printer.printAllocation(volunteers);
	}

	@Test
	public void testMoreVolunteer() throws RosterException {

		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		volunteers.add(volunteers.get(7));
		try {
			processor.generateRoster(volunteers);
		} catch(RosterException rx) {
		}
		printer.printAllocation(volunteers);
	}
	
	@Test
	public void testAllocationVolunteer() throws RosterException {
		volunteers.remove(7);
		try {
			processor.generateRoster(volunteers);
		} catch(RosterException rx) {
		}
		printer.printAllocation(volunteers);
	}
	
	@Test
	public void testShiftAllocationVolunteer() throws RosterException {
		volunteers.remove(7);
		volunteers.get(5).setAllocation(new DayShift(Day.TUESDAY, Shift.MORNING));
		try {
			processor.generateRoster(volunteers);
		} catch(RosterException rx) {
		}
		printer.printAllocation(volunteers);
	}
	
}