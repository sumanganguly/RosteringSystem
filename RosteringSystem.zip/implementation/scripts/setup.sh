#!/bin/bash
CLASSPATH="./../target/RosteringSystem-1.0-SNAPSHOT.jar;./../target/lib/*"

filelocation=${1}

java -cp $CLASSPATH com.amdocs.volunteer.roster.system.main.RosterGeneratorCaller "${filelocation}"
